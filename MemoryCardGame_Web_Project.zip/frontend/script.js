const symbols = ["🍎", "🚀", "🌈", "🐱", "🎧", "⚽", "🌻", "🦋"];
const board = document.getElementById("board");
const movesEl = document.getElementById("moves");
const pairsEl = document.getElementById("pairs");
const timeEl = document.getElementById("time");
const messageEl = document.getElementById("message");
const restartBtn = document.getElementById("restart");

let firstCard = null, lockBoard = false, moves = 0, matchedPairs = 0;
let startedAt = null, clockId = null, seconds = 0;

function shuffle(items) {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}
function formatTime(value) {
  return `${String(Math.floor(value / 60)).padStart(2, "0")}:${String(value % 60).padStart(2, "0")}`;
}
function startClock() {
  if (clockId) return;
  startedAt = Date.now();
  clockId = setInterval(() => {
    seconds = Math.floor((Date.now() - startedAt) / 1000);
    timeEl.textContent = formatTime(seconds);
  }, 250);
}
function stopClock() {
  if (clockId) clearInterval(clockId);
  clockId = null;
}
function updateStats() {
  movesEl.textContent = moves;
  pairsEl.textContent = `${matchedPairs} / 8`;
}
function makeBoard() {
  board.innerHTML = "";
  shuffle([...symbols, ...symbols]).forEach((symbol, index) => {
    const card = document.createElement("button");
    card.className = "card";
    card.type = "button";
    card.textContent = "?";
    card.setAttribute("aria-label", `Hidden card ${index + 1}`);
    card.dataset.symbol = symbol;
    card.addEventListener("click", () => flipCard(card));
    board.appendChild(card);
  });
}
function flipCard(card) {
  if (lockBoard || card.classList.contains("matched") || card === firstCard || card.classList.contains("revealed")) return;
  startClock();
  card.textContent = card.dataset.symbol;
  card.classList.add("revealed");
  card.setAttribute("aria-label", card.dataset.symbol);
  if (!firstCard) {
    firstCard = card;
    messageEl.textContent = "Find its matching pair.";
    return;
  }
  moves++;
  updateStats();
  if (firstCard.dataset.symbol === card.dataset.symbol) {
    firstCard.classList.add("matched");
    card.classList.add("matched");
    firstCard.disabled = true;
    card.disabled = true;
    firstCard = null;
    matchedPairs++;
    updateStats();
    if (matchedPairs === 8) {
      stopClock();
      messageEl.textContent = `You won in ${moves} moves and ${formatTime(seconds)}! 🎉`;
      saveScore();
    } else {
      messageEl.textContent = "Nice match! Keep going.";
    }
    return;
  }
  lockBoard = true;
  const previous = firstCard;
  firstCard = null;
  messageEl.textContent = "Not a match. Try again!";
  setTimeout(() => {
    [previous, card].forEach(item => {
      item.textContent = "?";
      item.classList.remove("revealed");
      item.setAttribute("aria-label", "Hidden card");
    });
    lockBoard = false;
  }, 800);
}
async function saveScore() {
  const apiBase = localStorage.getItem("memoryGameApiUrl");
  if (!apiBase) return; // Game works without a backend.
  try {
    await fetch(`${apiBase.replace(/\/$/, "")}/api/scores`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ moves, seconds })
    });
  } catch (error) {
    console.warn("Score could not be sent to the backend.", error);
  }
}
restartBtn.addEventListener("click", () => {
  stopClock();
  firstCard = null; lockBoard = false; moves = 0; matchedPairs = 0;
  seconds = 0; startedAt = null;
  timeEl.textContent = "00:00";
  messageEl.textContent = "Tap any card to begin.";
  updateStats();
  makeBoard();
});
makeBoard();
updateStats();
