package com.example.memorygame;

import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ScoreController {
    private final List<Map<String, Integer>> scores = new CopyOnWriteArrayList<>();

    @GetMapping("/health")
    public Map<String, String> health() {
        return Map.of("status", "ok", "service", "Memory Card Game API");
    }

    @PostMapping("/scores")
    public Map<String, String> saveScore(@RequestBody ScoreRequest request) {
        if (request.moves() < 0 || request.seconds() < 0) {
            throw new IllegalArgumentException("Moves and seconds must not be negative.");
        }
        scores.add(Map.of("moves", request.moves(), "seconds", request.seconds()));
        return Map.of("message", "Score received");
    }

    @GetMapping("/scores")
    public List<Map<String, Integer>> getScores() {
        return List.copyOf(scores);
    }

    public record ScoreRequest(int moves, int seconds) {}
}
