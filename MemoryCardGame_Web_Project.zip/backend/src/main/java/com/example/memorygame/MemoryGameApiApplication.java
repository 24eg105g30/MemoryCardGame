package com.example.memorygame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MemoryGameApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(MemoryGameApiApplication.class, args);
    }
}
