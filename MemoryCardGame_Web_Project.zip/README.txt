MEMORY CARD GAME - WEB VERSION

Folders:
- frontend: static browser game (HTML/CSS/JavaScript)
- backend: optional Spring Boot API that accepts and lists scores

IMPORTANT:
1. The browser game works without the backend.
2. The backend currently stores scores in memory only; scores are lost when the server restarts.
3. After deploying the backend, set the backend base URL in the browser using this in the browser console:
   localStorage.setItem("memoryGameApiUrl", "https://YOUR-BACKEND-URL")
   Then reload the game.
4. Keep frontend and backend in separate GitHub repositories if the college requires separate links.

Frontend deploy: Netlify (deploy the frontend folder) or GitHub Pages.
Backend deploy: Render using Docker, with the backend folder as the root directory.
